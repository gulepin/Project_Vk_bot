# -*- coding: utf8 -*-
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import wikipedia
import random
import requests


def main():
    slovo = '    '
    vk_session = vk_api.VkApi(
        token='''7c93ec15d109639896dd7ca5cd53cdb8f9e3207433800a67eb6c415
                 40cc6c5d3e5cd7cfb7098a3c7f98c9''')
    longpoll = VkBotLongPoll(vk_session, '194190167')
    url = 'https://translate.yandex.net/api/v1.5/tr.json/translate?'
    key = 'trnsl.1.1.20190227T075339Z.1b02a9ab6d4a47cc.f37d50831b51374ee600fd6aa0259419fd7ecd97'    
    
    for event in longpoll.listen():
        if event.type == VkBotEventType.MESSAGE_NEW:
            
            print('Для меня от:', event.obj.message['from_id'])
            print('Текст:', event.obj.message['text']) 
            
            user_text = event.obj.message['text'].strip()
            sp_hi = ['привет', 'ку', 'салам', 'hi', 'прив', 'здравствуй', 'начать',
                     'hello', 'хелоу', 'шалом', 'хай']
            sp = ['молоко', 'деревня', 'химия', 'устой']
            riddle = {'молоко': 'Питательная жидкость, предназначеная для вскармливание потомства',
                      'деревня': 'Небольшое крестьянское селение',
                      'химия': '''Одна из важнейших и обширных областей естествознания, наука
                                  о веществах, их составе и строении''',
                      'устой': 'Всплывшие наверх и сгустившиеся частицы устоявшейся жидкости'}
            
            if user_text.lower() in sp_hi:
                text = '''Ну здравствуй, мой дорогой друг, я бот, предназначенный для ответов на
                          твои вопросы по поводу стран, городов и т.д.,
                          а так же мы можем сыграть с тобой в увлекательную игру "Отгадай слово".<br>
                          Если хочешь поиграть, то пиши "Отгадай слово", однако если хочешь
                          что то узнать о стране, 
                          то пиши "Узнать", если ты что то забыл, то пиши "Помощь".'''
            elif user_text.lower()  == 'помощь': 
                text = '''Если хочешь поиграть, то пиши "Отгадай слово",
                          однако если хочешь что то узнать о стране, 
                          то пиши "Узнать", если ты что то забыл, то пиши "Помощь".'''
            elif user_text.lower() == 'отгадай слово': 
                slovo = random.choice(sp)
                text = riddle[slovo]
            elif user_text.lower() == slovo:
                text = '''Поздравляю, вы отгадали данное слово<br>
                          Если хотите ещё то напишите "Заново"'''
                slovo = ''
            elif user_text.lower() == 'заново': 
                slovo = random.choice(sp)
                text = riddle[slovo]
            elif user_text.lower() == 'узнать':
                text = '''Что бы узнать что то о стране введите сначала тему, а потом страну:<br>
                          "<Сюда надо написать тему, которая вас интересует>
                          <Сюда надо написать страну>"<br>
                          Так же я могу вывести список своих возможностей для данной
                          страны, для этого тебе надо написать:<br>
                          "Узнать возможность <Сюда надо написать страну>"'''
            elif len(user_text.split()) == 3 and user_text.split()[1].lower() == 'возможность':
                user_text = user_text.split()
                try:
                    text = ''
                    country = user_text[-1] + ' Country'
                    country = country[0].upper() + country[1:]
                    lang = 'ru-en'
                    translation_coutry = requests.post(url, data={'key': key,
                                                                  'text': country, 'lang': lang}).json()
                    sp_can = []
                    ny = wikipedia.page(''.join(translation_coutry["text"]))
                    if 'Экономика' not in text:
                        text_know = ny.section('Economy')
                        if text_know == '':
                            a = 1
                        elif text_know != None:    
                            if text == '':
                                text += 'Экономика'
                    if 'Религия' not in text:
                        text_know = ny.section('Religion')
                        if text_know == '':
                            a = 1
                        elif text_know != None:         
                            if text == '':
                                text += 'Религия'
                            else:
                                text += ', Религия'
                    if 'География' not in text:
                        text_know = ny.section('Geography')
                        if text_know == '':
                            a = 1
                        elif text_know != None:         
                            if text == '':
                                text += 'География'
                            else:
                                text += ', География'
                    if 'Население' not in text:
                        text_know = ny.section('Population')
                        if text_know == '':
                            a = 1
                        elif text_know != None:         
                            if text == '':
                                text += 'Население'
                            else:
                                text += ', Население'
                    if 'Культура' not in text:
                        text_know = ny.section('Culture')
                        if text_know == '':
                            a = 1
                        elif text_know != None:         
                            if text == '':
                                text += 'Культура'
                            else:
                                text += ', Культура'
                    if text == '':
                        text = 'К сожалению у меня нет информации для данной страны'
                except wikipedia.exceptions.PageError:
                    text = '''Это не страна или вы ввели не так как я вас просил,
                    но скорее всего я тебя просто не понял.'''
                except wikipedia.exceptions.DisambiguationError:
                    text = 'Сожалею, но мне этого не понять.'
            elif len(user_text.split()) >= 2:
                user_text = user_text.split()
                try:
                    country = user_text[-1]
                    country += ' Country'
                    country = country[0].upper() + country[1:]
                    quest = ' '.join(user_text[:-1])
                    quest = quest[0].upper() + quest[1:]
                    lang = 'ru-en'
                    translation_coutry = requests.post(url, data={'key': key,
                                                                  'text': country, 'lang': lang}).json()
                    translation_quest = requests.post(url, data={'key': key,
                                                                 'text': quest, 'lang': lang}).json()
                    ny = wikipedia.page(''.join(translation_coutry["text"]))
                    text_know = ny.section(''.join(translation_quest["text"]))
                    lang = 'en-ru'
                    r = requests.post(url, data={'key': key, 'text': text_know, 'lang': lang}).json()
                    if text_know == '':
                        text = '''К сожалению информации на интересующию вас
                                  тему у меня нет нужных данных или вы ввели какой то бред.'''
                    elif text_know != None:
                        text = ''.join(r["text"])
                    else:
                        text = '''К сожалению информации на интересующию вас
                                  тему у меня нет нужных данных или вы ввели какой то бред.'''
                except wikipedia.exceptions.PageError:
                    text = '''Это не страна или вы ввели не так как я вас просил,
                              но скорее всего я тебя просто не понял.''' 
                except wikipedia.exceptions.DisambiguationError:
                    text = '''Сожалею, но мне этого не понять.'''
                except KeyError:
                    text = 'Ошибка у меня.'
            else:
                text = 'Сожалею, но мне этого не понять.'
            if len(text) > 400:
                text = text[:400]
            vk = vk_session.get_api()
            vk.messages.send(user_id=event.obj.message['from_id'],
                             message=text,
                             random_id=random.randint(0,2 ** 64))
                
            
            
if __name__ == '__main__':
    main()